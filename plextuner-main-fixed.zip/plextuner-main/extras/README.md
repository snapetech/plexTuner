# Extras (optional)

Scripts and configs that are **not** part of the template core. Add or remove as needed for your environment.
