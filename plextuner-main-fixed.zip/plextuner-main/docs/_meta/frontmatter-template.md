---
id: <unique-kebab-id>
type: tutorial | how-to | reference | explanation
status: draft | stable | deprecated
tags: [tag1, tag2]
owners: [team or person, optional]
---

# Title (first H1 = doc title)

... body ...

See also
--------
- [Doc name](path/to/doc.md)

Related ADRs
------------
- *(optional)*

Related runbooks
----------------
- *(optional)*
