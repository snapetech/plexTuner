---
id: glossary
type: reference
status: stable
tags: [reference, glossary, vocabulary]
---

# Glossary

Key terms used across the docs. Add entries as your project introduces them.

| Term | Definition |
|------|------------|
| *(add project-specific terms)* | |

See also
--------
- [Docs index](index.md)

Related ADRs
------------
- *(none)*

Related runbooks
----------------
- *(none)*
