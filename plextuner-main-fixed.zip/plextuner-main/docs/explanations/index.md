---
id: explanations-index
type: reference
status: stable
tags: [explanations, index]
---

# Explanations (why, architecture, concepts)

Background and rationale. Add project-specific explanation docs here.

| Doc | Description |
|-----|-------------|
| *(none yet)* | Add architecture, design tradeoffs, concepts as needed. |

See also
--------
- [ADR index](../adr/index.md).
- [Reference](../reference/index.md).
