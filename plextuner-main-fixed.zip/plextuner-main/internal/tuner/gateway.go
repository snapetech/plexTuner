package tuner

import (
	"bufio"
	"bytes"
	"context"
	"encoding/base64"
	"encoding/json"
	"encoding/xml"
	"errors"
	"io"
	"log"
	"net/http"
	"net/url"
	"os"
	"os/exec"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/plextuner/plex-tuner/internal/catalog"
	"github.com/plextuner/plex-tuner/internal/httpclient"
	"github.com/plextuner/plex-tuner/internal/safeurl"
)

// Gateway proxies live stream requests to provider URLs with optional auth.
// Limit concurrent streams to TunerCount (tuner semantics).
type Gateway struct {
	Channels            []catalog.LiveChannel
	ProviderUser        string
	ProviderPass        string
	TunerCount          int
	StreamBufferBytes   int    // 0 = no buffer, -1 = auto
	StreamTranscodeMode string // "off" | "on" | "auto"
	TranscodeOverrides  map[string]bool
	DefaultProfile      string
	ProfileOverrides    map[string]string
	Client              *http.Client
	PlexPMSURL          string
	PlexPMSToken        string
	PlexClientAdapt     bool
	mu                  sync.Mutex
	inUse               int
}

func getenvInt(key string, def int) int {
	v := strings.TrimSpace(os.Getenv(key))
	if v == "" {
		return def
	}
	n, err := strconv.Atoi(v)
	if err != nil {
		return def
	}
	return n
}

func getenvFloat(key string, def float64) float64 {
	v := strings.TrimSpace(os.Getenv(key))
	if v == "" {
		return def
	}
	f, err := strconv.ParseFloat(v, 64)
	if err != nil {
		return def
	}
	return f
}

func getenvBool(key string, def bool) bool {
	v := strings.TrimSpace(strings.ToLower(os.Getenv(key)))
	if v == "" {
		return def
	}
	return v == "1" || v == "true" || v == "yes" || v == "on"
}

type startSignalState struct {
	TSLikePackets int
	HasIDR        bool
	HasAAC        bool
	AlignedOffset int
}

func looksLikeGoodTSStart(buf []byte) startSignalState {
	const pkt = 188
	st := startSignalState{}
	st.AlignedOffset = -1
	// Quick TS sanity and payload scan for H264 IDR + AAC/ADTS.
	for off := 0; off+pkt <= len(buf); {
		if buf[off] != 0x47 {
			// Resync locally.
			n := bytes.IndexByte(buf[off+1:], 0x47)
			if n < 0 {
				break
			}
			off += n + 1
			continue
		}
		st.TSLikePackets++
		if st.AlignedOffset < 0 {
			// Prefer a packet boundary that looks stable for a few packets.
			ok := 0
			for k := off; k < len(buf) && ok < 4; k += pkt {
				if k >= len(buf) || buf[k] != 0x47 {
					break
				}
				ok++
			}
			if ok >= 3 {
				st.AlignedOffset = off
			}
		}
		p := buf[off : off+pkt]
		afc := (p[3] >> 4) & 0x3
		i := 4
		if afc == 0 || afc == 2 { // reserved or adaptation-only
			off += pkt
			continue
		}
		if afc == 3 {
			if i >= len(p) {
				off += pkt
				continue
			}
			alen := int(p[i])
			i++
			i += alen
		}
		if i >= len(p) {
			off += pkt
			continue
		}
		payload := p[i:]
		// H264 Annex B IDR (NAL type 5)
		if !st.HasIDR {
			if bytes.Contains(payload, []byte{0x00, 0x00, 0x01, 0x65}) || bytes.Contains(payload, []byte{0x00, 0x00, 0x00, 0x01, 0x65}) {
				st.HasIDR = true
			}
		}
		// AAC ADTS syncword
		if !st.HasAAC {
			for j := 0; j+1 < len(payload); j++ {
				if payload[j] == 0xFF && (payload[j+1]&0xF0) == 0xF0 {
					st.HasAAC = true
					break
				}
			}
		}
		if st.HasIDR && st.HasAAC && st.TSLikePackets >= 8 {
			return st
		}
		off += pkt
	}
	return st
}

type plexForwardedHints struct {
	SessionIdentifier string
	ClientIdentifier  string
	Product           string
	Platform          string
	Device            string
	Raw               map[string]string
}

type plexResolvedClient struct {
	SessionIdentifier string
	ClientIdentifier  string
	Product           string
	Platform          string
	Title             string
}

func (h plexForwardedHints) empty() bool {
	return h.SessionIdentifier == "" && h.ClientIdentifier == "" && h.Product == "" && h.Platform == "" && h.Device == ""
}

func (h plexForwardedHints) summary() string {
	parts := []string{}
	if h.SessionIdentifier != "" {
		parts = append(parts, `sid="`+h.SessionIdentifier+`"`)
	}
	if h.ClientIdentifier != "" {
		parts = append(parts, `cid="`+h.ClientIdentifier+`"`)
	}
	if h.Product != "" {
		parts = append(parts, `product="`+h.Product+`"`)
	}
	if h.Platform != "" {
		parts = append(parts, `platform="`+h.Platform+`"`)
	}
	if h.Device != "" {
		parts = append(parts, `device="`+h.Device+`"`)
	}
	if len(h.Raw) > 0 {
		parts = append(parts, `raw=`+strconv.Itoa(len(h.Raw)))
	}
	if len(parts) == 0 {
		return "none"
	}
	return strings.Join(parts, " ")
}

func plexRequestHints(r *http.Request) plexForwardedHints {
	get := func(keys ...string) string {
		for _, k := range keys {
			if v := strings.TrimSpace(r.Header.Get(k)); v != "" {
				return v
			}
			if v := strings.TrimSpace(r.URL.Query().Get(k)); v != "" {
				return v
			}
			// Also allow lowercase query/header names.
			lk := strings.ToLower(k)
			if v := strings.TrimSpace(r.Header.Get(lk)); v != "" {
				return v
			}
			if v := strings.TrimSpace(r.URL.Query().Get(lk)); v != "" {
				return v
			}
		}
		return ""
	}
	raw := map[string]string{}
	for k, vals := range r.Header {
		kl := strings.ToLower(k)
		if !strings.HasPrefix(kl, "x-plex-") {
			continue
		}
		if len(vals) > 0 && strings.TrimSpace(vals[0]) != "" {
			raw[k] = strings.TrimSpace(vals[0])
		}
	}
	for k, vals := range r.URL.Query() {
		kl := strings.ToLower(k)
		if !strings.Contains(kl, "plex") && !strings.Contains(kl, "session") && !strings.Contains(kl, "client") {
			continue
		}
		if len(vals) > 0 && strings.TrimSpace(vals[0]) != "" {
			raw["q:"+k] = strings.TrimSpace(vals[0])
		}
	}
	return plexForwardedHints{
		SessionIdentifier: get("X-Plex-Session-Identifier", "session", "sessionId", "session_id"),
		ClientIdentifier:  get("X-Plex-Client-Identifier", "X-Plex-Target-Client-Identifier", "clientIdentifier", "client_id"),
		Product:           get("X-Plex-Product"),
		Platform:          get("X-Plex-Platform", "X-Plex-Client-Platform"),
		Device:            get("X-Plex-Device", "X-Plex-Device-Name"),
		Raw:               raw,
	}
}

func xmlStartAttr(start xml.StartElement, name string) string {
	for _, a := range start.Attr {
		if a.Name.Local == name {
			return a.Value
		}
	}
	return ""
}

func (g *Gateway) resolvePlexClient(ctx context.Context, hints plexForwardedHints) (*plexResolvedClient, error) {
	if g == nil || !g.PlexClientAdapt {
		return nil, nil
	}
	if strings.TrimSpace(g.PlexPMSURL) == "" || strings.TrimSpace(g.PlexPMSToken) == "" {
		return nil, nil
	}
	if hints.SessionIdentifier == "" && hints.ClientIdentifier == "" {
		return nil, nil
	}
	base := strings.TrimRight(strings.TrimSpace(g.PlexPMSURL), "/")
	u := base + "/status/sessions?X-Plex-Token=" + url.QueryEscape(strings.TrimSpace(g.PlexPMSToken))
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, u, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("User-Agent", "PlexTuner/1.0")
	client := g.Client
	if client == nil {
		client = httpclient.ForStreaming()
	}
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return nil, errors.New("pms /status/sessions status=" + strconv.Itoa(resp.StatusCode))
	}
	dec := xml.NewDecoder(resp.Body)
	type candidate struct {
		title    string
		player   plexResolvedClient
		session  string
		clientID string
	}
	var stack []string
	var cur *candidate
	for {
		tok, err := dec.Token()
		if err == io.EOF {
			break
		}
		if err != nil {
			return nil, err
		}
		switch t := tok.(type) {
		case xml.StartElement:
			stack = append(stack, t.Name.Local)
			switch t.Name.Local {
			case "Video", "Track", "Photo", "Metadata":
				if cur == nil {
					cur = &candidate{
						title: xmlStartAttr(t, "title"),
					}
				}
			case "Player":
				if cur != nil {
					cur.player.ClientIdentifier = xmlStartAttr(t, "machineIdentifier")
					cur.player.Product = xmlStartAttr(t, "product")
					cur.player.Platform = xmlStartAttr(t, "platform")
					if cur.player.Platform == "" {
						cur.player.Platform = xmlStartAttr(t, "platformTitle")
					}
				}
			case "Session":
				if cur != nil {
					cur.session = xmlStartAttr(t, "id")
				}
			}
		case xml.EndElement:
			if len(stack) > 0 {
				stack = stack[:len(stack)-1]
			}
			if cur != nil && (t.Name.Local == "Video" || t.Name.Local == "Track" || t.Name.Local == "Photo" || t.Name.Local == "Metadata") {
				matchSID := hints.SessionIdentifier != "" && cur.session != "" && cur.session == hints.SessionIdentifier
				matchCID := hints.ClientIdentifier != "" && cur.player.ClientIdentifier != "" && cur.player.ClientIdentifier == hints.ClientIdentifier
				if matchSID || matchCID {
					out := cur.player
					out.SessionIdentifier = cur.session
					out.Title = cur.title
					if out.ClientIdentifier == "" {
						out.ClientIdentifier = hints.ClientIdentifier
					}
					if out.SessionIdentifier == "" {
						out.SessionIdentifier = hints.SessionIdentifier
					}
					return &out, nil
				}
				cur = nil
			}
		}
	}
	return nil, nil
}

func looksLikePlexWeb(s string) bool {
	v := strings.ToLower(strings.TrimSpace(s))
	return strings.Contains(v, "plex web") || strings.Contains(v, "web") || strings.Contains(v, "browser") || strings.Contains(v, "firefox") || strings.Contains(v, "chrome") || strings.Contains(v, "safari")
}

func (g *Gateway) requestAdaptation(ctx context.Context, r *http.Request, channel *catalog.LiveChannel, channelID string) (bool, string, string) {
	hints := plexRequestHints(r)
	log.Printf("gateway: channel=%q id=%s plex-hints %s", channel.GuideName, channelID, hints.summary())
	// Explicit override always wins and is deterministic.
	explicitProfile := normalizeProfileName(r.URL.Query().Get("profile"))
	if strings.TrimSpace(r.URL.Query().Get("profile")) != "" {
		switch explicitProfile {
		case profilePlexSafe, profileAACCFR, profileVideoOnly, profileLowBitrate, profileDashFast:
			return true, explicitProfile, "query-profile"
		default:
			return false, explicitProfile, "query-profile"
		}
	}
	if !g.PlexClientAdapt {
		return false, "", "adapt-disabled"
	}
	info, err := g.resolvePlexClient(ctx, hints)
	if err != nil {
		log.Printf("gateway: channel=%q id=%s plex-client-resolve err=%v", channel.GuideName, channelID, err)
		return false, "", "resolve-error"
	}
	if info == nil {
		return false, "", "no-forwarded-id"
	}
	log.Printf("gateway: channel=%q id=%s plex-client-resolved sid=%q cid=%q product=%q platform=%q title=%q",
		channel.GuideName, channelID, info.SessionIdentifier, info.ClientIdentifier, info.Product, info.Platform, info.Title)
	if looksLikePlexWeb(info.Product) || looksLikePlexWeb(info.Platform) {
		return true, profilePlexSafe, "resolved-web-client"
	}
	return false, "", "resolved-nonweb-client"
}

// Adaptive buffer tuning: grow when client is slow (backpressure), shrink when client keeps up.
const (
	adaptiveBufferMin       = 32 << 10 // 32 KiB
	adaptiveBufferMax       = 2 << 20  // 2 MiB
	adaptiveBufferInitial   = 64 << 10 // 64 KiB (keep first-byte latency low)
	adaptiveSlowFlushMs     = 100
	adaptiveFastFlushMs     = 20
	adaptiveFastCountShrink = 3
	adaptiveFlushIntervalMs = 50 // force periodic flush to avoid long startup stalls
)

type adaptiveWriter struct {
	w            io.Writer
	buf          bytes.Buffer
	targetSize   int
	minSize      int
	maxSize      int
	slowThresh   time.Duration
	fastThresh   time.Duration
	fastCount    int
	fastCountMax int
	lastFlush    time.Time
	flushEvery   time.Duration
}

func newAdaptiveWriter(w io.Writer) *adaptiveWriter {
	return &adaptiveWriter{
		w:            w,
		targetSize:   adaptiveBufferInitial,
		minSize:      adaptiveBufferMin,
		maxSize:      adaptiveBufferMax,
		slowThresh:   adaptiveSlowFlushMs * time.Millisecond,
		fastThresh:   adaptiveFastFlushMs * time.Millisecond,
		fastCountMax: adaptiveFastCountShrink,
		lastFlush:    time.Now(),
		flushEvery:   adaptiveFlushIntervalMs * time.Millisecond,
	}
}

func (a *adaptiveWriter) Write(p []byte) (int, error) {
	n, err := a.buf.Write(p)
	if err != nil {
		return n, err
	}
	for a.buf.Len() >= a.targetSize {
		if err := a.flushToClient(); err != nil {
			return n, err
		}
	}
	// Avoid pathological startup stalls: flush a partial buffer periodically.
	if a.flushEvery > 0 && a.buf.Len() > 0 && time.Since(a.lastFlush) >= a.flushEvery {
		if err := a.flushToClient(); err != nil {
			return n, err
		}
	}
	return n, nil
}

func (a *adaptiveWriter) flushToClient() error {
	if a.buf.Len() == 0 {
		return nil
	}
	start := time.Now()
	for a.buf.Len() > 0 {
		n, err := a.w.Write(a.buf.Bytes())
		if err != nil {
			return err
		}
		if n <= 0 {
			break
		}
		// bytes.Buffer doesn't advance on Write; drop leading n bytes
		remaining := a.buf.Bytes()[n:]
		a.buf.Reset()
		a.buf.Write(remaining)
	}
	a.lastFlush = time.Now()
	d := time.Since(start)
	if d >= a.slowThresh {
		if a.targetSize < a.maxSize {
			a.targetSize *= 2
			if a.targetSize > a.maxSize {
				a.targetSize = a.maxSize
			}
		}
		a.fastCount = 0
	} else if d <= a.fastThresh {
		a.fastCount++
		if a.fastCount >= a.fastCountMax {
			a.fastCount = 0
			if a.targetSize > a.minSize {
				a.targetSize /= 2
				if a.targetSize < a.minSize {
					a.targetSize = a.minSize
				}
			}
		}
	} else {
		a.fastCount = 0
	}
	return nil
}

func (a *adaptiveWriter) Flush() error { return a.flushToClient() }

// streamWriter wraps w with an optional buffer. Call flush before returning.
// bufferBytes: >0 = fixed size (bufio); 0 = passthrough; -1 = adaptive.
func streamWriter(w http.ResponseWriter, bufferBytes int) (io.Writer, func()) {
	if bufferBytes == 0 {
		return w, func() {}
	}
	if bufferBytes == -1 {
		// If we can flush, ensure flush happens after each underlying write.
		// This matters for Plex Live TV startup: PMS can be extremely sensitive
		// to "200 OK but no bytes" windows.
		under := io.Writer(w)
		if f, ok := w.(http.Flusher); ok {
			under = flushWriter{w: w, f: f}
		}
		aw := newAdaptiveWriter(under)
		return aw, func() { _ = aw.Flush() }
	}
	bw := bufio.NewWriterSize(w, bufferBytes)
	return bw, func() { _ = bw.Flush() }
}

const (
	profileDefault    = "default"
	profilePlexSafe   = "plexsafe"
	profileAACCFR     = "aaccfr"
	profileVideoOnly  = "videoonlyfast"
	profileLowBitrate = "lowbitrate"
	profileDashFast   = "dashfast"
)

func normalizeProfileName(v string) string {
	switch strings.ToLower(strings.TrimSpace(v)) {
	case "", "default":
		return profileDefault
	case "plexsafe", "plex-safe", "safe":
		return profilePlexSafe
	case "aaccfr", "aac-cfr", "aac":
		return profileAACCFR
	case "videoonlyfast", "video-only-fast", "videoonly", "video":
		return profileVideoOnly
	case "lowbitrate", "low-bitrate", "low":
		return profileLowBitrate
	case "dashfast", "dash-fast":
		return profileDashFast
	default:
		return profileDefault
	}
}

func defaultProfileFromEnv() string {
	p := strings.TrimSpace(os.Getenv("PLEX_TUNER_PROFILE"))
	if p != "" {
		return normalizeProfileName(p)
	}
	// Back-compat for the old boolean.
	if strings.EqualFold(os.Getenv("PLEX_TUNER_PLEX_SAFE"), "1") ||
		strings.EqualFold(os.Getenv("PLEX_TUNER_PLEX_SAFE"), "true") ||
		strings.EqualFold(os.Getenv("PLEX_TUNER_PLEX_SAFE"), "yes") {
		return profilePlexSafe
	}
	return profileDefault
}

func loadProfileOverridesFile(path string) (map[string]string, error) {
	path = strings.TrimSpace(path)
	if path == "" {
		return nil, nil
	}
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	raw := map[string]string{}
	if err := json.Unmarshal(b, &raw); err != nil {
		return nil, err
	}
	out := make(map[string]string, len(raw))
	for k, v := range raw {
		k = strings.TrimSpace(k)
		if k == "" {
			continue
		}
		out[k] = normalizeProfileName(v)
	}
	return out, nil
}

func loadTranscodeOverridesFile(path string) (map[string]bool, error) {
	path = strings.TrimSpace(path)
	if path == "" {
		return nil, nil
	}
	b, err := os.ReadFile(path)
	if err != nil {
		return nil, err
	}
	// Accept either {"id": true} or {"id":"on"/"off"} for convenience.
	boolMap := map[string]bool{}
	if err := json.Unmarshal(b, &boolMap); err == nil {
		return boolMap, nil
	}
	strMap := map[string]string{}
	if err := json.Unmarshal(b, &strMap); err != nil {
		return nil, err
	}
	out := make(map[string]bool, len(strMap))
	for k, v := range strMap {
		k = strings.TrimSpace(k)
		if k == "" {
			continue
		}
		switch strings.ToLower(strings.TrimSpace(v)) {
		case "1", "true", "yes", "on", "transcode":
			out[k] = true
		case "0", "false", "no", "off", "remux", "copy":
			out[k] = false
		}
	}
	return out, nil
}

func (g *Gateway) firstProfileOverride(keys ...string) (string, bool) {
	if g == nil || g.ProfileOverrides == nil {
		return "", false
	}
	for _, k := range keys {
		k = strings.TrimSpace(k)
		if k == "" {
			continue
		}
		if p, ok := g.ProfileOverrides[k]; ok && strings.TrimSpace(p) != "" {
			return normalizeProfileName(p), true
		}
	}
	return "", false
}

func (g *Gateway) profileForChannel(channelID string) string {
	if p, ok := g.firstProfileOverride(channelID); ok {
		return p
	}
	if g != nil && strings.TrimSpace(g.DefaultProfile) != "" {
		return normalizeProfileName(g.DefaultProfile)
	}
	return defaultProfileFromEnv()
}

func (g *Gateway) profileForChannelMeta(channelID, guideNumber, tvgID string) string {
	if p, ok := g.firstProfileOverride(channelID, guideNumber, tvgID); ok {
		return p
	}
	return g.profileForChannel("")
}

func (g *Gateway) effectiveTranscode(ctx context.Context, streamURL string) bool {
	switch strings.ToLower(strings.TrimSpace(g.StreamTranscodeMode)) {
	case "on":
		return true
	case "off", "":
		return false
	case "auto_cached", "cached_auto":
		// Caller should pass a channel-aware decision via effectiveTranscodeForChannel.
		return false
	case "auto":
		need, err := g.needTranscode(ctx, streamURL)
		if err != nil {
			log.Printf("gateway: ffprobe auto transcode check failed url=%s err=%v (using transcode)", safeurl.RedactURL(streamURL), err)
			return true
		}
		return need
	default:
		return false
	}
}

func (g *Gateway) firstTranscodeOverride(keys ...string) (bool, bool) {
	if g == nil || g.TranscodeOverrides == nil {
		return false, false
	}
	for _, k := range keys {
		k = strings.TrimSpace(k)
		if k == "" {
			continue
		}
		if v, ok := g.TranscodeOverrides[k]; ok {
			return v, true
		}
	}
	return false, false
}

func (g *Gateway) effectiveTranscodeForChannel(ctx context.Context, channelID, streamURL string) bool {
	return g.effectiveTranscodeForChannelMeta(ctx, channelID, "", "", streamURL)
}

func (g *Gateway) effectiveTranscodeForChannelMeta(ctx context.Context, channelID, guideNumber, tvgID, streamURL string) bool {
	mode := strings.ToLower(strings.TrimSpace(g.StreamTranscodeMode))
	if mode == "auto_cached" || mode == "cached_auto" {
		if v, ok := g.firstTranscodeOverride(channelID, guideNumber, tvgID); ok {
			log.Printf("gateway: transcode auto_cached match id=%q guide=%q tvg=%q -> %t", channelID, guideNumber, tvgID, v)
			return v
		}
		log.Printf("gateway: transcode auto_cached miss id=%q guide=%q tvg=%q (default remux)", channelID, guideNumber, tvgID)
		// Fast-path fallback for uncached channels: keep startup latency low.
		return false
	}
	return g.effectiveTranscode(ctx, streamURL)
}

func (g *Gateway) needTranscode(ctx context.Context, streamURL string) (bool, error) {
	ffprobePath, err := exec.LookPath("ffprobe")
	if err != nil {
		return true, err
	}
	ctx, cancel := context.WithTimeout(ctx, 6*time.Second)
	defer cancel()
	probe := func(sel string) (string, error) {
		args := []string{"-v", "error", "-nostdin", "-rw_timeout", "5000000", "-user_agent", "PlexTuner/1.0"}
		if g.ProviderUser != "" || g.ProviderPass != "" {
			auth := base64.StdEncoding.EncodeToString([]byte(g.ProviderUser + ":" + g.ProviderPass))
			args = append(args, "-headers", "Authorization: Basic "+auth+"\r\n")
		}
		args = append(args, "-select_streams", sel, "-show_entries", "stream=codec_name", "-of", "default=noprint_wrappers=1:nokey=1", streamURL)
		out, err := exec.CommandContext(ctx, ffprobePath, args...).Output()
		return strings.TrimSpace(string(out)), err
	}
	v, err := probe("v:0")
	if err != nil || !isPlexFriendlyVideoCodec(v) {
		return true, err
	}
	a, err := probe("a:0")
	if err != nil || !isPlexFriendlyAudioCodec(a) {
		return true, err
	}
	return false, nil
}

func isPlexFriendlyVideoCodec(name string) bool {
	switch strings.ToLower(name) {
	case "h264", "avc", "mpeg2video", "mpeg4":
		return true
	default:
		return false
	}
}

func isPlexFriendlyAudioCodec(name string) bool {
	switch strings.ToLower(name) {
	case "aac", "ac3", "eac3", "mp3", "mp2":
		return true
	default:
		return false
	}
}

func (g *Gateway) effectiveBufferSize(transcode bool) int {
	if g.StreamBufferBytes >= 0 {
		return g.StreamBufferBytes
	}
	if transcode {
		return -1
	}
	return 0
}

func (g *Gateway) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	if !strings.HasPrefix(r.URL.Path, "/stream/") {
		http.NotFound(w, r)
		return
	}
	channelID := strings.TrimPrefix(r.URL.Path, "/stream/")
	if channelID == "" {
		http.NotFound(w, r)
		return
	}
	var channel *catalog.LiveChannel
	for i := range g.Channels {
		if g.Channels[i].ChannelID == channelID {
			channel = &g.Channels[i]
			break
		}
	}
	if channel == nil {
		// Fallback: numeric index for backwards compatibility when ChannelID is not set
		if idx, err := strconv.Atoi(channelID); err == nil && idx >= 0 && idx < len(g.Channels) {
			channel = &g.Channels[idx]
		}
	}
	if channel == nil {
		http.NotFound(w, r)
		return
	}
	forceTranscode, forcedProfile, adaptReason := g.requestAdaptation(r.Context(), r, channel, channelID)
	if adaptReason != "" && adaptReason != "adapt-disabled" {
		log.Printf("gateway: channel=%q id=%s adapt transcode=%t profile=%q reason=%s", channel.GuideName, channelID, forceTranscode, forcedProfile, adaptReason)
	}
	start := time.Now()
	urls := channel.StreamURLs
	if len(urls) == 0 && channel.StreamURL != "" {
		urls = []string{channel.StreamURL}
	}
	if len(urls) == 0 {
		http.Error(w, "no stream URL", http.StatusBadGateway)
		return
	}

	g.mu.Lock()
	limit := g.TunerCount
	if limit <= 0 {
		limit = 2
	}
	if g.inUse >= limit {
		g.mu.Unlock()
		log.Printf("gateway: channel=%q id=%s reject all-tuners-in-use limit=%d ua=%q", channel.GuideName, channelID, limit, r.UserAgent())
		w.Header().Set("X-HDHomeRun-Error", "805") // All Tuners In Use
		http.Error(w, "All tuners in use", http.StatusServiceUnavailable)
		return
	}
	g.inUse++
	inUseNow := g.inUse
	g.mu.Unlock()
	defer func() {
		g.mu.Lock()
		g.inUse--
		g.mu.Unlock()
	}()

	// Try primary then backups until one works. Do not retry or backoff on 429/423 here:
	// that would block stream throughput. We only fail over to next URL and return 502 if all fail.
	// Reject non-http(s) URLs to prevent SSRF (e.g. file:// or provider-supplied internal URLs).
	for i, streamURL := range urls {
		if !safeurl.IsHTTPOrHTTPS(streamURL) {
			if i == 0 {
				log.Printf("gateway: channel %s: invalid stream URL scheme (rejected)", channel.GuideName)
			}
			continue
		}
		req, err := http.NewRequestWithContext(r.Context(), http.MethodGet, streamURL, nil)
		if err != nil {
			continue
		}
		if g.ProviderUser != "" || g.ProviderPass != "" {
			req.SetBasicAuth(g.ProviderUser, g.ProviderPass)
		}
		req.Header.Set("User-Agent", "PlexTuner/1.0")

		client := g.Client
		if client == nil {
			client = httpclient.ForStreaming()
		}
		resp, err := client.Do(req)
		if err != nil {
			log.Printf("gateway: channel=%q id=%s upstream[%d/%d] error url=%s err=%v",
				channel.GuideName, channelID, i+1, len(urls), safeurl.RedactURL(streamURL), err)
			continue
		}
		if resp.StatusCode != http.StatusOK {
			if resp.StatusCode == http.StatusTooManyRequests {
				log.Printf("gateway: channel=%q id=%s upstream[%d/%d] 429 rate limited url=%s",
					channel.GuideName, channelID, i+1, len(urls), safeurl.RedactURL(streamURL))
			} else {
				log.Printf("gateway: channel=%q id=%s upstream[%d/%d] status=%d url=%s",
					channel.GuideName, channelID, i+1, len(urls), resp.StatusCode, safeurl.RedactURL(streamURL))
			}
			resp.Body.Close()
			continue
		}
		// Reject 200 with empty body (e.g. Cloudflare/redirect returning 0 bytes) — try next URL (learned from k3s IPTV hardening).
		if resp.ContentLength == 0 {
			log.Printf("gateway: channel=%q id=%s upstream[%d/%d] empty-body url=%s ct=%q",
				channel.GuideName, channelID, i+1, len(urls), safeurl.RedactURL(streamURL), resp.Header.Get("Content-Type"))
			resp.Body.Close()
			continue
		}
		log.Printf("gateway: channel=%q id=%s start upstream[%d/%d] url=%s ct=%q cl=%d inuse=%d/%d ua=%q",
			channel.GuideName, channelID, i+1, len(urls), safeurl.RedactURL(streamURL), resp.Header.Get("Content-Type"), resp.ContentLength, inUseNow, limit, r.UserAgent())
		for k, v := range resp.Header {
			if k == "Content-Length" || k == "Transfer-Encoding" {
				continue
			}
			for _, vv := range v {
				w.Header().Add(k, vv)
			}
		}
		if isHLSResponse(resp, streamURL) {
			body, err := io.ReadAll(resp.Body)
			resp.Body.Close()
			if err != nil {
				log.Printf("gateway: channel=%q id=%s read-playlist-failed err=%v", channel.GuideName, channelID, err)
				continue
			}
			body = rewriteHLSPlaylist(body, streamURL)
			firstSeg := firstHLSMediaLine(body)
			transcode := g.effectiveTranscodeForChannelMeta(r.Context(), channelID, channel.GuideNumber, channel.TVGID, streamURL)
			if forceTranscode {
				transcode = true
			}
			bufferSize := g.effectiveBufferSize(transcode)
			mode := "remux"
			if transcode {
				mode = "transcode"
			}
			bufDesc := strconv.Itoa(bufferSize)
			if bufferSize == -1 {
				bufDesc = "adaptive"
			}
			log.Printf("gateway: channel=%q id=%s hls-playlist bytes=%d first-seg=%q dur=%s (relaying as ts, %s buffer=%s)",
				channel.GuideName, channelID, len(body), firstSeg, time.Since(start).Round(time.Millisecond), mode, bufDesc)
			log.Printf("gateway: channel=%q id=%s hls-mode transcode=%t mode=%q guide=%q tvg=%q", channel.GuideName, channelID, transcode, g.StreamTranscodeMode, channel.GuideNumber, channel.TVGID)
			if ffmpegPath, ffmpegErr := exec.LookPath("ffmpeg"); ffmpegErr == nil {
				if err := g.relayHLSWithFFmpeg(w, r, ffmpegPath, streamURL, channel.GuideName, channelID, channel.GuideNumber, channel.TVGID, start, transcode, bufferSize, forcedProfile); err == nil {
					return
				} else {
					log.Printf("gateway: channel=%q id=%s ffmpeg-%s failed (falling back to go relay): %v",
						channel.GuideName, channelID, mode, err)
				}
			}
			if err := g.relayHLSAsTS(w, r, client, streamURL, body, channel.GuideName, channelID, start, bufferSize); err != nil {
				log.Printf("gateway: channel=%q id=%s hls-relay failed: %v", channel.GuideName, channelID, err)
				continue
			}
			return
		}
		bufferSize := g.effectiveBufferSize(false)
		w.WriteHeader(resp.StatusCode)
		sw, flush := streamWriter(w, bufferSize)
		n, _ := io.Copy(sw, resp.Body)
		resp.Body.Close()
		flush()
		log.Printf("gateway: channel=%q id=%s proxied bytes=%d dur=%s", channel.GuideName, channelID, n, time.Since(start).Round(time.Millisecond))
		return
	}
	log.Printf("gateway: channel=%q id=%s all %d upstream(s) failed dur=%s", channel.GuideName, channelID, len(urls), time.Since(start).Round(time.Millisecond))
	http.Error(w, "All upstreams failed", http.StatusBadGateway)
}

func (g *Gateway) relayHLSWithFFmpeg(
	w http.ResponseWriter,
	r *http.Request,
	ffmpegPath string,
	playlistURL string,
	channelName string,
	channelID string,
	guideNumber string,
	tvgID string,
	start time.Time,
	transcode bool,
	bufferBytes int,
	forcedProfile string,
) error {
	profile := g.profileForChannelMeta(channelID, guideNumber, tvgID)
	if strings.TrimSpace(forcedProfile) != "" {
		profile = normalizeProfileName(forcedProfile)
	}

	args := []string{
		"-nostdin",
		"-hide_banner",
		"-loglevel", "error",
		"-fflags", "+discardcorrupt+genpts+nobuffer",
		"-analyzeduration", "1000000",
		"-probesize", "1000000",
		"-rw_timeout", "15000000",
		"-user_agent", "PlexTuner/1.0",
	}
	if g.ProviderUser != "" || g.ProviderPass != "" {
		auth := base64.StdEncoding.EncodeToString([]byte(g.ProviderUser + ":" + g.ProviderPass))
		args = append(args, "-headers", "Authorization: Basic "+auth+"\r\n")
	}
	var codecArgs []string
	if !transcode {
		codecArgs = []string{
			"-i", playlistURL,
			"-map", "0:v:0",
			"-map", "0:a?",
			"-c", "copy",
		}
	} else {
		codecArgs = []string{
			"-i", playlistURL,
			"-map", "0:v:0",
			"-map", "0:a:0?",
			"-sn",
			"-dn",
			"-c:v", "libx264",
			"-a53cc", "0",
			"-preset", "veryfast",
			"-tune", "zerolatency",
			"-x264-params", "repeat-headers=1:keyint=30:min-keyint=30:scenecut=0:force-cfr=1",
			"-pix_fmt", "yuv420p",
			"-g", "30",
			"-keyint_min", "30",
			"-sc_threshold", "0",
			"-force_key_frames", "expr:gte(t,n_forced*1)",
		}
	}
	if transcode {
		switch profile {
		case profilePlexSafe:
			// More conservative output tends to make Plex Web's DASH startup happier.
			codecArgs = append(codecArgs,
				"-vf", "fps=30000/1001,format=yuv420p",
				"-b:v", "2200k",
				"-maxrate", "2500k",
				"-bufsize", "5000k",
				"-c:a", "libmp3lame",
				"-ac", "2",
				"-ar", "48000",
				"-b:a", "128k",
				"-af", "aresample=async=1:first_pts=0",
			)
		case profileAACCFR:
			codecArgs = append(codecArgs,
				// Browser-oriented "boring" output to help Plex Web DASH startup.
				"-vf", "fps=30000/1001,scale='min(854,iw)':-2,format=yuv420p",
				"-profile:v", "baseline",
				"-level:v", "3.1",
				"-bf", "0",
				"-refs", "1",
				"-b:v", "1400k",
				"-maxrate", "1400k",
				"-bufsize", "1400k",
				"-c:a", "aac",
				"-profile:a", "aac_low",
				"-ac", "2",
				"-ar", "48000",
				"-b:a", "96k",
				"-af", "aresample=async=1:first_pts=0",
				"-x264-params", "repeat-headers=1:keyint=30:min-keyint=30:scenecut=0:force-cfr=1:nal-hrd=cbr:bframes=0:aud=1",
			)
		case profileVideoOnly:
			codecArgs = append(codecArgs,
				"-vf", "fps=30000/1001,format=yuv420p",
				"-b:v", "2200k",
				"-maxrate", "2500k",
				"-bufsize", "5000k",
				"-an",
			)
		case profileLowBitrate:
			codecArgs = append(codecArgs,
				"-vf", "fps=30000/1001,scale='trunc(iw/2)*2:trunc(ih/2)*2',format=yuv420p",
				"-b:v", "1400k",
				"-maxrate", "1700k",
				"-bufsize", "3400k",
				"-c:a", "aac",
				"-profile:a", "aac_low",
				"-ac", "2",
				"-ar", "48000",
				"-b:a", "96k",
				"-af", "aresample=async=1:first_pts=0",
			)
		case profileDashFast:
			// Aggressively optimize for Plex Web DASH startup readiness.
			codecArgs = append(codecArgs,
				"-vf", "fps=30000/1001,scale='min(1280,iw)':-2,format=yuv420p",
				"-b:v", "1800k",
				"-maxrate", "1800k",
				"-bufsize", "1800k",
				"-c:a", "aac",
				"-profile:a", "aac_low",
				"-ac", "2",
				"-ar", "48000",
				"-b:a", "96k",
				"-af", "aresample=async=1:first_pts=0",
				"-x264-params", "repeat-headers=1:keyint=30:min-keyint=30:scenecut=0:force-cfr=1:nal-hrd=cbr",
			)
		default:
			codecArgs = append(codecArgs,
				"-b:v", "3500k",
				"-maxrate", "4000k",
				"-bufsize", "8000k",
				"-c:a", "aac",
				"-profile:a", "aac_low",
				"-ac", "2",
				"-ar", "48000",
				"-b:a", "128k",
				"-af", "aresample=async=1:first_pts=0",
			)
		}
		// Help Plex's live parser lock onto a clean TS timeline/header faster.
		codecArgs = append(codecArgs,
			"-muxrate", "3000000",
			"-pcr_period", "20",
			"-pat_period", "0.05",
		)
	}
	codecArgs = append(codecArgs,
		"-flush_packets", "1",
		"-max_interleave_delta", "0",
		"-muxdelay", "0",
		"-muxpreload", "0",
		"-mpegts_flags", "+resend_headers+pat_pmt_at_frames+initial_discontinuity",
		"-f", "mpegts",
		"pipe:1",
	)
	args = append(args, codecArgs...)

	cmd := exec.CommandContext(r.Context(), ffmpegPath, args...)
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		return err
	}
	var stderr bytes.Buffer
	cmd.Stderr = &stderr
	if err := cmd.Start(); err != nil {
		return err
	}
	modeLabel := "ffmpeg-remux"
	if transcode {
		modeLabel = "ffmpeg-transcode"
	}
	log.Printf("gateway: channel=%q id=%s %s profile=%s", channelName, channelID, modeLabel, profile)
	// Live TV startup race mitigation:
	// 1) send an immediate, deterministic TS bootstrap (optional) so PMS has bytes fast.
	// 2) gate real TS bytes through a holdback buffer (optional) so we don't feed PMS a
	//    "random mid-stream" opening that delays/blocks manifest creation.
	startupMin := getenvInt("PLEX_TUNER_WEBSAFE_STARTUP_MIN_BYTES", 65536)
	startupMax := getenvInt("PLEX_TUNER_WEBSAFE_STARTUP_MAX_BYTES", 786432)
	startupTimeoutMs := getenvInt("PLEX_TUNER_WEBSAFE_STARTUP_TIMEOUT_MS", 30000)
	bootstrapSec := getenvFloat("PLEX_TUNER_WEBSAFE_BOOTSTRAP_SECONDS", 1.5)
	bootstrapEnabled := getenvBool("PLEX_TUNER_WEBSAFE_BOOTSTRAP", true)
	bootstrapAll := getenvBool("PLEX_TUNER_WEBSAFE_BOOTSTRAP_ALL", false)
	enableBootstrap := bootstrapEnabled && (transcode || bootstrapAll)
	requireGoodStart := transcode && getenvBool("PLEX_TUNER_WEBSAFE_REQUIRE_GOOD_START", true)

	w.Header().Set("Content-Type", "video/mp2t")
	w.Header().Del("Content-Length")
	w.WriteHeader(http.StatusOK)

	// IMPORTANT: write bootstrap directly to the ResponseWriter (before any buffering wrappers)
	// so PMS sees bytes immediately.
	if enableBootstrap && bootstrapSec > 0 {
		if err := writeBootstrapTS(r.Context(), ffmpegPath, w, channelName, channelID, bootstrapSec); err != nil {
			log.Printf("gateway: channel=%q id=%s bootstrap failed: %v", channelName, channelID, err)
		}
		if joinDelayMs := getenvInt("PLEX_TUNER_WEBSAFE_JOIN_DELAY_MS", 0); joinDelayMs > 0 {
			if joinDelayMs > 5000 {
				joinDelayMs = 5000
			}
			log.Printf("gateway: channel=%q id=%s websafe-join-delay ms=%d", channelName, channelID, joinDelayMs)
			select {
			case <-time.After(time.Duration(joinDelayMs) * time.Millisecond):
			case <-r.Context().Done():
				return nil
			}
		}
	}

	bodyOut, flushBody := streamWriter(w, bufferBytes)
	defer flushBody()

	dst := io.Writer(bodyOut)
	// If enabled, hold back the first chunk of TS bytes until they look like a clean start.
	if transcode && startupMin > 0 {
		tmo := time.Duration(startupTimeoutMs) * time.Millisecond
		if tmo <= 0 {
			tmo = 30 * time.Second
		}
		dst = newTSHoldback(w, dst, startupMin, startupMax, tmo, requireGoodStart, channelName, channelID, modeLabel, start)
	}
	// Log first bytes that actually reach the response pipeline.
	dst = &firstWriteLogger{w: dst, channelName: channelName, channelID: channelID, start: start, modeLabel: modeLabel}

	n, copyErr := io.Copy(dst, stdout)
	waitErr := cmd.Wait()

	if r.Context().Err() != nil {
		log.Printf("gateway: channel=%q id=%s %s client-done bytes=%d dur=%s",
			channelName, channelID, modeLabel, n, time.Since(start).Round(time.Millisecond))
		return nil
	}
	if copyErr != nil && r.Context().Err() == nil {
		return copyErr
	}
	if waitErr != nil && r.Context().Err() == nil {
		msg := strings.TrimSpace(stderr.String())
		if msg == "" {
			msg = waitErr.Error()
		}
		return errors.New(msg)
	}
	log.Printf("gateway: channel=%q id=%s %s bytes=%d dur=%s",
		channelName, channelID, modeLabel, n, time.Since(start).Round(time.Millisecond))
	return nil
}

type firstWriteLogger struct {
	w           io.Writer
	once        sync.Once
	channelName string
	channelID   string
	start       time.Time
	modeLabel   string
}

func (f *firstWriteLogger) Write(p []byte) (int, error) {
	f.once.Do(func() {
		label := f.modeLabel
		if strings.TrimSpace(label) == "" {
			label = "stream"
		}
		log.Printf("gateway: channel=%q id=%s %s first-bytes=%d startup=%s",
			f.channelName, f.channelID, label, len(p), time.Since(f.start).Round(time.Millisecond))
	})
	return f.w.Write(p)
}

// tsHoldback gates TS output until we have a plausible start (or a timeout), to reduce
// Plex Live TV startup races where PMS returns 200 but internal manifests (HLS/DASH)
// aren't ready yet.
//
// This writer ALWAYS forwards bytes eventually; it never "steals" bytes like a
// separate prefetch goroutine can.
type tsHoldback struct {
	mu            sync.Mutex
	dst           io.Writer
	flusher       http.Flusher
	minBytes      int
	maxBytes      int
	deadline      time.Time
	requireGood   bool
	channelName   string
	channelID     string
	modeLabel     string
	start         time.Time
	buf           []byte
	released      bool
	releaseReason string
	state         startSignalState
}

func newTSHoldback(w http.ResponseWriter, dst io.Writer, minBytes, maxBytes int, timeout time.Duration, requireGood bool, channelName, channelID, modeLabel string, start time.Time) *tsHoldback {
	var fl http.Flusher
	if f, ok := w.(http.Flusher); ok {
		fl = f
	}
	if minBytes <= 0 {
		minBytes = 64 << 10
	}
	if maxBytes < minBytes {
		maxBytes = minBytes
	}
	if maxBytes > 4<<20 {
		maxBytes = 4 << 20
	}
	if timeout <= 0 {
		timeout = 30 * time.Second
	}
	return &tsHoldback{
		dst:         dst,
		flusher:     fl,
		minBytes:    minBytes,
		maxBytes:    maxBytes,
		deadline:    time.Now().Add(timeout),
		requireGood: requireGood,
		channelName: channelName,
		channelID:   channelID,
		modeLabel:   modeLabel,
		start:       start,
		state:       startSignalState{AlignedOffset: -1},
	}
}

func (h *tsHoldback) Write(p []byte) (int, error) {
	h.mu.Lock()
	if h.released {
		h.mu.Unlock()
		n, err := h.dst.Write(p)
		if n > 0 && h.flusher != nil {
			h.flusher.Flush()
		}
		return n, err
	}
	// Buffer up to maxBytes (never unbounded). If this write would overflow the
	// buffer, treat the remainder as "overflow" and forward it once we release.
	room := h.maxBytes - len(h.buf)
	overflow := []byte(nil)
	if room > 0 {
		if len(p) > room {
			h.buf = append(h.buf, p[:room]...)
			overflow = p[room:]
		} else {
			h.buf = append(h.buf, p...)
		}
		// Update TS start state on buffered data.
		h.state = looksLikeGoodTSStart(h.buf)
	} else {
		overflow = p
	}

	good := !h.requireGood || (h.state.HasIDR && h.state.HasAAC && h.state.TSLikePackets >= 8)
	if len(h.buf) >= h.maxBytes {
		h.released = true
		h.releaseReason = "max"
	} else if len(h.buf) >= h.minBytes && good {
		h.released = true
		h.releaseReason = "good"
	} else if time.Now().After(h.deadline) {
		h.released = true
		h.releaseReason = "timeout"
	}
	if !h.released {
		h.mu.Unlock()
		// We consumed p into the internal buffer (as much as we can). Report full write
		// to keep io.Copy moving; we will release buffered bytes later.
		return len(p), nil
	}

	// Release: align to a stable TS boundary if we found one.
	buf := h.buf
	st := h.state
	if st.AlignedOffset > 0 && st.AlignedOffset < len(buf) {
		buf = buf[st.AlignedOffset:]
	}
	// Clear buffer before writing to avoid re-entrancy weirdness.
	h.buf = nil
	reason := h.releaseReason
	ch := h.channelName
	id := h.channelID
	mode := h.modeLabel
	startup := time.Since(h.start).Round(time.Millisecond)
	h.mu.Unlock()

	if len(buf) > 0 {
		_, err := h.dst.Write(buf)
		if err != nil {
			return len(p), err
		}
		if h.flusher != nil {
			h.flusher.Flush()
		}
	}
	if len(overflow) > 0 {
		_, err := h.dst.Write(overflow)
		if err != nil {
			return len(p), err
		}
		if h.flusher != nil {
			h.flusher.Flush()
		}
	}
	log.Printf(
		"gateway: channel=%q id=%s %s holdback-release reason=%s bytes=%d startup=%s ts_pkts=%d idr=%t aac=%t align=%d",
		ch, id, mode, reason, len(buf), startup, st.TSLikePackets, st.HasIDR, st.HasAAC, st.AlignedOffset,
	)
	return len(p), nil
}

type flushWriter struct {
	w io.Writer
	f http.Flusher
}

func (fw flushWriter) Write(p []byte) (int, error) {
	n, err := fw.w.Write(p)
	if n > 0 {
		fw.f.Flush()
	}
	return n, err
}

var (
	bootstrapMu    sync.Mutex
	bootstrapCache = map[int][]byte{}
)

func bootstrapKey(seconds float64) int {
	if seconds <= 0 {
		return 0
	}
	// milliseconds (rounded) is plenty for config-driven values.
	return int(seconds*1000 + 0.5)
}

func getBootstrapTSBytes(ctx context.Context, ffmpegPath string, seconds float64) ([]byte, error) {
	if seconds <= 0 {
		return nil, nil
	}
	if seconds > 5 {
		seconds = 5
	}
	key := bootstrapKey(seconds)
	bootstrapMu.Lock()
	if b, ok := bootstrapCache[key]; ok {
		bootstrapMu.Unlock()
		return b, nil
	}
	bootstrapMu.Unlock()

	args := []string{
		"-nostdin",
		"-hide_banner",
		"-loglevel", "error",
		"-f", "lavfi", "-i", "color=c=black:s=1280x720:r=30000/1001",
		"-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo",
		"-t", strconv.FormatFloat(seconds, 'f', 2, 64),
		"-shortest",
		"-map", "0:v:0",
		"-map", "1:a:0",
		"-c:v", "libx264",
		"-preset", "ultrafast",
		"-tune", "zerolatency",
		"-pix_fmt", "yuv420p",
		"-g", "30",
		"-keyint_min", "30",
		"-sc_threshold", "0",
		"-x264-params", "repeat-headers=1:keyint=30:min-keyint=30:scenecut=0:force-cfr=1:nal-hrd=cbr",
		"-b:v", "900k",
		"-maxrate", "900k",
		"-bufsize", "900k",
		"-c:a", "aac",
		"-profile:a", "aac_low",
		"-ac", "2",
		"-ar", "48000",
		"-b:a", "96k",
		"-af", "aresample=async=1:first_pts=0",
		"-flush_packets", "1",
		"-muxdelay", "0",
		"-muxpreload", "0",
		"-mpegts_flags", "+resend_headers+pat_pmt_at_frames+initial_discontinuity",
		"-f", "mpegts",
		"pipe:1",
	}
	cmd := exec.CommandContext(ctx, ffmpegPath, args...)
	var stderr bytes.Buffer
	cmd.Stderr = &stderr
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		return nil, err
	}
	if err := cmd.Start(); err != nil {
		return nil, err
	}
	var out bytes.Buffer
	// Cap to something sane; bootstrap is tiny (<~1MB).
	_, copyErr := io.CopyN(&out, stdout, 6<<20)
	if copyErr != nil && !errors.Is(copyErr, io.EOF) {
		_ = cmd.Process.Kill()
		_ = cmd.Wait()
		return nil, copyErr
	}
	waitErr := cmd.Wait()
	if waitErr != nil {
		msg := strings.TrimSpace(stderr.String())
		if msg == "" {
			msg = waitErr.Error()
		}
		return nil, errors.New(msg)
	}
	b := out.Bytes()
	if len(b) == 0 {
		return nil, errors.New("bootstrap produced no data")
	}
	bootstrapMu.Lock()
	bootstrapCache[key] = append([]byte(nil), b...)
	bootstrapMu.Unlock()
	return b, nil
}

func writeBootstrapTS(ctx context.Context, ffmpegPath string, w http.ResponseWriter, channelName, channelID string, seconds float64) error {
	if seconds <= 0 {
		return nil
	}
	b, err := getBootstrapTSBytes(ctx, ffmpegPath, seconds)
	if err != nil {
		return err
	}
	if len(b) == 0 {
		return nil
	}
	n, werr := w.Write(b)
	if n > 0 {
		if f, ok := w.(http.Flusher); ok {
			f.Flush()
		}
		log.Printf("gateway: channel=%q id=%s bootstrap-ts bytes=%d dur=%.2fs", channelName, channelID, n, seconds)
	}
	if werr != nil {
		return werr
	}
	return nil
}

func (g *Gateway) relayHLSAsTS(
	w http.ResponseWriter,
	r *http.Request,
	client *http.Client,
	playlistURL string,
	initialPlaylist []byte,
	channelName string,
	channelID string,
	start time.Time,
	bufferBytes int,
) error {
	if client == nil {
		client = httpclient.ForStreaming()
	}
	// We're not returning the playlist; we're returning a TS byte stream.
	w.Header().Set("Content-Type", "video/mp2t")
	w.Header().Del("Content-Length")
	sw, flush := streamWriter(w, bufferBytes)
	defer flush()
	flusher, _ := w.(http.Flusher)
	seen := map[string]struct{}{}
	lastProgress := time.Now()
	sentBytes := int64(0)
	sentSegments := 0
	headerSent := false
	currentPlaylistURL := playlistURL
	currentPlaylist := initialPlaylist

	for {
		select {
		case <-r.Context().Done():
			log.Printf("gateway: channel=%q id=%s hls-relay client-done segs=%d bytes=%d dur=%s",
				channelName, channelID, sentSegments, sentBytes, time.Since(start).Round(time.Millisecond))
			return nil
		default:
		}

		mediaLines := hlsMediaLines(currentPlaylist)
		// Prune seen to only segment URLs still in playlist so map doesn't grow unbounded.
		segmentURLSet := make(map[string]struct{}, len(mediaLines))
		for _, u := range mediaLines {
			if !strings.HasSuffix(strings.ToLower(u), ".m3u8") {
				segmentURLSet[u] = struct{}{}
			}
		}
		for u := range seen {
			if _, inPlaylist := segmentURLSet[u]; !inPlaylist {
				delete(seen, u)
			}
		}
		if len(mediaLines) == 0 {
			if !headerSent {
				return errors.New("hls playlist has no media lines")
			}
			if time.Since(lastProgress) > 12*time.Second {
				return errors.New("hls relay stalled (no media lines)")
			}
			time.Sleep(1 * time.Second)
		} else {
			progressThisPass := false
			for _, segURL := range mediaLines {
				if strings.HasSuffix(strings.ToLower(segURL), ".m3u8") {
					// Some providers return a master/variant indirection; follow one level.
					next, err := g.fetchAndRewritePlaylist(r, client, segURL)
					if err != nil {
						if !headerSent {
							return err
						}
						log.Printf("gateway: channel=%q id=%s nested-playlist fetch failed url=%s err=%v",
							channelName, channelID, safeurl.RedactURL(segURL), err)
						continue
					}
					currentPlaylistURL = segURL
					currentPlaylist = next
					progressThisPass = true
					break
				}
				if _, ok := seen[segURL]; ok {
					continue
				}
				seen[segURL] = struct{}{}
				n, err := g.fetchAndWriteSegment(w, sw, r, client, segURL, headerSent)
				if err != nil {
					if !headerSent {
						return err
					}
					if r.Context().Err() != nil {
						return nil
					}
					log.Printf("gateway: channel=%q id=%s segment fetch failed url=%s err=%v",
						channelName, channelID, safeurl.RedactURL(segURL), err)
					continue
				}
				if !headerSent {
					headerSent = true
					if flusher != nil {
						flusher.Flush()
					}
				}
				if n > 0 {
					sentBytes += n
					sentSegments++
					lastProgress = time.Now()
					progressThisPass = true
				}
				if flusher != nil {
					flusher.Flush()
				}
			}

			if !progressThisPass && time.Since(lastProgress) > 12*time.Second {
				if !headerSent {
					return errors.New("hls relay stalled before first segment")
				}
				log.Printf("gateway: channel=%q id=%s hls-relay ended no-new-segments segs=%d bytes=%d dur=%s",
					channelName, channelID, sentSegments, sentBytes, time.Since(start).Round(time.Millisecond))
				return nil
			}
			sleepHLSRefresh(currentPlaylist)
		}

		next, err := g.fetchAndRewritePlaylist(r, client, currentPlaylistURL)
		if err != nil {
			if !headerSent {
				return err
			}
			if r.Context().Err() != nil {
				return nil
			}
			if time.Since(lastProgress) > 12*time.Second {
				return err
			}
			log.Printf("gateway: channel=%q id=%s playlist refresh failed url=%s err=%v",
				channelName, channelID, safeurl.RedactURL(currentPlaylistURL), err)
			sleepHLSRefresh(currentPlaylist)
			continue
		}
		currentPlaylist = next
	}
}

// sleepHLSRefresh sleeps based on playlist EXT-X-TARGETDURATION to avoid hammering upstream (1–10s).
func sleepHLSRefresh(playlistBody []byte) {
	sec := hlsTargetDurationSeconds(playlistBody)
	if sec <= 0 {
		sec = 3
	}
	half := sec / 2
	if half < 1 {
		half = 1
	}
	if half > 10 {
		half = 10
	}
	time.Sleep(time.Duration(half) * time.Second)
}

func (g *Gateway) fetchAndRewritePlaylist(r *http.Request, client *http.Client, playlistURL string) ([]byte, error) {
	req, err := http.NewRequestWithContext(r.Context(), http.MethodGet, playlistURL, nil)
	if err != nil {
		return nil, err
	}
	if g.ProviderUser != "" || g.ProviderPass != "" {
		req.SetBasicAuth(g.ProviderUser, g.ProviderPass)
	}
	req.Header.Set("User-Agent", "PlexTuner/1.0")
	resp, err := client.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return nil, errors.New("playlist http status " + strconv.Itoa(resp.StatusCode))
	}
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}
	return rewriteHLSPlaylist(body, playlistURL), nil
}

func (g *Gateway) fetchAndWriteSegment(
	w http.ResponseWriter,
	bodyOut io.Writer,
	r *http.Request,
	client *http.Client,
	segURL string,
	headerSent bool,
) (int64, error) {
	if bodyOut == nil {
		bodyOut = w
	}
	req, err := http.NewRequestWithContext(r.Context(), http.MethodGet, segURL, nil)
	if err != nil {
		return 0, err
	}
	if g.ProviderUser != "" || g.ProviderPass != "" {
		req.SetBasicAuth(g.ProviderUser, g.ProviderPass)
	}
	req.Header.Set("User-Agent", "PlexTuner/1.0")
	resp, err := client.Do(req)
	if err != nil {
		return 0, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return 0, errors.New("segment http status " + strconv.Itoa(resp.StatusCode))
	}
	if !headerSent {
		w.Header().Set("Content-Type", "video/mp2t")
		w.Header().Del("Content-Length")
		w.WriteHeader(http.StatusOK)
	}
	n, err := io.Copy(bodyOut, resp.Body)
	return n, err
}

func isHLSResponse(resp *http.Response, upstreamURL string) bool {
	ct := strings.ToLower(resp.Header.Get("Content-Type"))
	if strings.Contains(ct, "mpegurl") || strings.Contains(ct, "m3u") {
		return true
	}
	return strings.Contains(strings.ToLower(upstreamURL), ".m3u8")
}

func rewriteHLSPlaylist(body []byte, upstreamURL string) []byte {
	base, err := url.Parse(upstreamURL)
	if err != nil || base == nil {
		return body
	}
	var out bytes.Buffer
	sc := bufio.NewScanner(bytes.NewReader(body))
	first := true
	for sc.Scan() {
		if !first {
			out.WriteByte('\n')
		}
		first = false
		line := sc.Text()
		trim := strings.TrimSpace(line)
		if trim == "" || strings.HasPrefix(trim, "#") {
			out.WriteString(line)
			continue
		}
		if strings.HasPrefix(trim, "//") {
			out.WriteString(base.Scheme + ":" + trim)
			continue
		}
		ref, perr := url.Parse(trim)
		if perr != nil {
			out.WriteString(line)
			continue
		}
		if ref.IsAbs() {
			out.WriteString(trim)
			continue
		}
		out.WriteString(base.ResolveReference(ref).String())
	}
	// Preserve trailing newline if present in input.
	if len(body) > 0 && body[len(body)-1] == '\n' {
		out.WriteByte('\n')
	}
	return out.Bytes()
}

func firstHLSMediaLine(body []byte) string {
	lines := hlsMediaLines(body)
	if len(lines) == 0 {
		return ""
	}
	return lines[0]
}

func hlsMediaLines(body []byte) []string {
	sc := bufio.NewScanner(bytes.NewReader(body))
	var out []string
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		out = append(out, line)
	}
	return out
}

// hlsTargetDurationSeconds parses #EXT-X-TARGETDURATION from playlist body; returns 0 if missing/invalid.
func hlsTargetDurationSeconds(body []byte) int {
	sc := bufio.NewScanner(bytes.NewReader(body))
	for sc.Scan() {
		line := strings.TrimSpace(sc.Text())
		if strings.HasPrefix(line, "#EXT-X-TARGETDURATION:") {
			v := strings.TrimSpace(strings.TrimPrefix(line, "#EXT-X-TARGETDURATION:"))
			if n, err := strconv.Atoi(v); err == nil && n > 0 {
				return n
			}
			return 0
		}
	}
	return 0
}
